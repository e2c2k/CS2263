#include <stdio.h>

int main(){

    int array[5];
    array[0] = 10;
    array[1] = 58;
    array[2] = 25;
    array[3] = 9;
    array[4] = 27;
    
    array[-1] = 32;
    
    
    
    printf("\nIndex[-1] = %d\n", array[-1]);
}
